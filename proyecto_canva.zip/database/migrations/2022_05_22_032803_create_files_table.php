<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('files', function (Blueprint $table) {
            $table->increments('files_id');
            $table->integer('categories_id')->nullable();
            $table->LongText('files_name')->nullable();
            $table->LongText('files_url')->nullable();
            $table->date('files_date')->nullable();
            $table->LongText('files_portada')->nullable();
            $table->LongText('publish_content')->nullable();
            $table->integer('files_status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('files');
    }
}
