<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@800&display=swap" rel="stylesheet">
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">


    <style>
        .navbar{
            padding-top:22px;
        }

        .wrapper {
            display: flex;
            align-items: stretch;
        }

        #sidebar {
            min-width: 250px;
            max-width: 250px;
            min-height: 100vh;
            overflow: scroll;
            overflow-x: auto;
        }

        #siderbar a{
            color: #0e0e0e;
        }

        #sidebar.active {
            margin-left: -250px;
        }
        #sidebar a[data-toggle="collapse"] {
            position: relative;
        }

        #sidebar .dropdown-toggle::after {
            display: block;
            position: absolute;
            top: 50%;
            right: 20px;
            transform: translateY(-50%);
        }

        @media (max-width: 768px) {
            #sidebar {
                margin-left: -250px;
            }
            #sidebar.active {
                margin-left: 0;
            }
        }
        
        #sidebar {
            /* don't forget to add all the previously mentioned styles here too */
            background: #ffffff;
            color: #222;
            transition: all 0.3s;
        }

        #sidebar .sidebar-header {
            padding: 20px;
            background: #ffffff;
        }

        #sidebar ul.components {
            padding: 20px 0;
        }

        #sidebar ul p {
            color: #fff;
            padding: 10px;
        }

        #sidebar ul li a {
            padding: 9px;
            font-size: 1.1em;
            display: block;
            border-radius: 7px;
            margin: 15px;
            text-decoration: none;
        }
        #sidebar ul li a:hover {
            color: #7386D5;
            background: #00000008;
        }

        #sidebar ul li.active > a, a[aria-expanded="true"] {
            color: #000;
            background: #0000002e;
        }

        #navbarDropdown{
            background: #c7c6c6;
            border-radius: 46px;
            height: 38px;
            width: 100%;
        }
    </style>
</head>
<body style="background: #ffffff !important;">
    <div id="app">

        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
            <?php if(Auth::user()): ?>
                <button type="button" id="sidebarCollapse" class="btn btn-info">
                    <span><i class="fas fa-bars"></i></span>
                </button>
            <?php endif; ?>

                <a class="navbar-brand" style="padding:5px;">
                    <?php echo e(config('app.name', 'Canva')); ?>

                </a>
                
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>   
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <i class="fas fa-user" style="font-size: 25px;left:5px;background: #ffff;padding: 3px;border-radius: 18px;"></i> <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a href="#" class="dropdown-item">Mi Perfil</a>
                                    <hr>
                                    <a href="#" class="dropdown-item">Item</a>
                                    <a href="#" class="dropdown-item">Item</a>
                                    <a href="#" class="dropdown-item">Item</a>
                                    <a href="#" class="dropdown-item">Item</a>
                                    <hr>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Cerrar Sesión')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <?php if(auth()->guard()->guest()): ?>
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php endif; ?>

        <?php if(Auth::user()): ?>
        <div class="wrapper">
            <!-- Sidebar -->
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3>Canva</h3>
                </div>

                <ul class="list-unstyled components">
                    <li class="active">
                        <a href="<?php echo e(url('home')); ?>"> <i class="fa fa-home"></i> Home</a>
                    </li>
                    <?php if(session('user')->roles_id == 1): ?> 
                    <li>
                        <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Item 1</a>
                        <ul class="collapse list-unstyled" id="pageSubmenu">
                            <li>
                                <a href="<?php echo e(url('category')); ?>">Categorias</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('files')); ?>">Publicar</a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <?php if(session('user')->roles_id == 2): ?> 
                        <li>
                            <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Item 1</a>
                            <ul class="collapse list-unstyled" id="pageSubmenu">
                                <li>
                                    <a href="#">item</a>
                                </li>
                                <li>
                                    <a href="#">item</a>
                                </li>
                            </ul>
                        </li>                         
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('my_files')); ?>"><?php echo e(__('Item')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('my_files')); ?>"><?php echo e(__('Item')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('my_files')); ?>"><?php echo e(__('Item')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('my_files')); ?>"><?php echo e(__('Item')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('my_files')); ?>"><?php echo e(__('Item')); ?></a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
        <?php endif; ?>
        

        
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!--carousel Owl-->
    <script defer src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>    
    <script>
        $(document).ready(function () {

            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });

        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\proyecto_canva\resources\views/layouts/app.blade.php ENDPATH**/ ?>